package blog;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class BlogDAO {

	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
		
	//		---------- DB���� ----------  //
	public BlogDAO() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/Blog_db";//mysql ��ġ
			String dbID = "root";//mysql ID
			String dbPassword = "root";//mysql PASSWORD
			Class.forName("com.mysql.cj.jdbc.Driver");//���� ����̹�
			conn=DriverManager.getConnection(dbURL, dbID, dbPassword);//DB�������� �� ����
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//�ڵ����� ��ȣ
	public int getNext() {
		String SQL = "SELECT ȸ����ȣ FROM Blog ORDER BY ȸ����ȣ DESC";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1) + 1;
			}else {
				return 1;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;//����
	}
		
	//������
	public int write(Integer Number, String Title, String Content) {
		String SQL = "INSERT INTO Blog VALUES(?,?,?)";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());
			pstmt.setString(2, Title);
			pstmt.setString(3, Content);
			return pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;//�����ͺ��̽� ����
	}


		
	//���
	public ArrayList<Blog> getList(){
		String SQL = "SELECT * FROM Blog ORDER BY ȸ����ȣ DESC";                        
		ArrayList<Blog> list = new ArrayList<Blog>();
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				Blog blog = new Blog();
				blog.setNumber(rs.getInt(1));
				blog.setTitle(rs.getString(2));
				blog.setContent(rs.getString(3));
				list.add(blog);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	//�����б�
	 public Blog getBlog(int Number) {
		 String SQL = "SELECT * FROM Blog WHERE ȸ����ȣ = ?";
		 try {
				PreparedStatement pstmt=conn.prepareStatement(SQL);
				pstmt.setInt(1, Number);
				rs=pstmt.executeQuery();
				if(rs.next()) {
					Blog blog = new Blog();
					blog.setNumber(rs.getInt(1));
					blog.setTitle(rs.getString(2));
					blog.setContent(rs.getString(3));
					return blog;
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		 return null;
	 }

	
	
	
	
}